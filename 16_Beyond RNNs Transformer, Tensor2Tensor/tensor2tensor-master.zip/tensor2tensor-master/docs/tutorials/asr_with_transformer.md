# Automated Speech Recognition with the Transformer model

See the
[official tutorial](https://cloud.google.com/tpu/docs/tutorials/automated-speech-recognition).
